# FLA CLA-2 – Finite Automata and Pushdown Automata

Course: **21CSC301T – Formal Language and Automata**, SRM IST Tiruchirappalli
Student: **Siva Balan S (RA2411026050230)**
Guide: Dr. C. Gunasundari, Department of AIML

Python implementation of the machines designed in the CLA-2 report:

| Task | Machine | Type |
|---|---|---|
| Task 2 | M1 – ATM PIN format (exactly 4 digits) | DFA, 6 states |
| Task 2 | M2 – card lock after 3 wrong attempts | DFA, 5 states |
| Task 2 | M_T + M_len – password policy (product construction, 60 reachable states) | DFAs |
| Task 2 | M3 – e-mail format `name@domain.tld` | DFA, 10 states |
| Task 3 | P1 – balanced parentheses | DPDA |
| Task 3 | P2 – arithmetic expressions from E → E+T \| T, T → T*F \| F, F → (E) \| id | NPDA (CFG → PDA) |
| Task 3 | P3 – palindromes w c wᴿ | DPDA |
| Task 3 | P4 – palindromes w wᴿ | NPDA (guesses the middle) |
| Task 4 (team) | LoopGuard – infinite-loop detector (TERMINATES / LOOPS / UNKNOWN) | fixed bound + linear ranking + cycle detection + step budget |

No external libraries are needed – only Python 3.8 or newer.

## Project structure

```
automata/   dfa.py  – DFA class with step-by-step traces
            pda.py  – PDA simulator over instantaneous descriptions (q, w, stack),
                      works for deterministic and non-deterministic PDAs,
                      plus a DPDA check
task2/      machines.py – the Task 2 DFAs and character classifiers
task3/      machines.py – the Task 3 PDAs and a parse-tree counter for ambiguity
task4/      loopguard.py – Task 4 LoopGuard infinite-loop detector (team task)
tests/      test_task2.py, test_task3.py
demo.py     command-line demonstration
sample_output.txt – output of `python demo.py`
```

## How to run

```bash
python demo.py                      # accept/reject tables for every machine
python demo.py task2                # only Task 2
python demo.py task3                # only Task 3
python demo.py trace pin 12a4       # step-by-step trace of one string
python demo.py trace password "Pass@123"
python demo.py trace email ravi@abc.in
python demo.py trace brackets "(())()"
python demo.py trace expr "id+id*id"
python demo.py trace wcwr abcba
python -m task4.loopguard           # Task 4: verdicts for the ten benchmark loops
```

Example trace:

```
$ python demo.py trace brackets "(())()"
(q0, (())(), Z0) ⊢ (q1, ())(), XZ0) ⊢ (q1, ))(), XXZ0) ⊢ (q1, )(), XZ0) ⊢ (q1, (), Z0)
⊢ (q0, (), Z0) ⊢ (q1, ), XZ0) ⊢ (q1, ε, Z0) ⊢ (q0, ε, Z0)   ->  Accept
```

## Tests

```bash
python -m unittest discover -s tests -t . -v
```

16 tests check:

* every accepted and rejected string from the report (Tables 5 and 8);
* that the password product DFA has exactly 60 reachable states;
* each Task 2 DFA against an independent regular-expression rule on **every** short string
  (all PIN strings up to length 6, all password class strings up to length 9,
  all e-mail strings up to length 8, all card-lock strings up to length 8);
* each PDA against an independent checker on every short string
  (brackets up to length 8, palindromes up to length 7, expressions up to 7 tokens);
* which PDAs are deterministic (P1, P3) and which are not (P2, P4);
* ambiguity: `id+id*id` has 2 parse trees in the ambiguous grammar and 1 in the revised grammar;
* Task 4: every benchmark verdict, the linear check against real execution on 1,078 small loops,
  a proved verdict for all 1,024 loops over 8-bit integers, and that every LOOPS-by-cycle loop
  really never exits.

## Task 4 (team work): LoopGuard

Team: Siva Balan S (RA2411026050230), Shabari Raj Kumar S (RA2411026050227), Shailesh M (RA2411026050223).
See `CONTRIBUTIONS.md` for who did what.

"Does this loop run forever?" is the complement of the Halting Problem: undecidable and not even
recognizable. `task4/loopguard.py` therefore never claims an exact answer for every loop:

* **TERMINATES** – only with a proof: a fixed bound, a ranking function, or the loop exited;
* **LOOPS** – only with a proof: the guard can never become false, or a full loop state repeated;
* **UNKNOWN** – no proof within the step budget (hand over to a runtime watchdog).

```
$ python -m task4.loopguard
L1 bounded for-loop           TERMINATES   syntactic bound
L2 countdown by 3             TERMINATES   linear ranking
L3 wrong direction            LOOPS        linear ranking
L4 forgotten update           LOOPS        linear ranking
L5 binary search (bug)        LOOPS        cycle detection   state (2, 3) repeats
L6 binary search (fixed)      TERMINATES   bounded run
L7 traffic-light controller   LOOPS        cycle detection
L8 skip zero, 16-bit          LOOPS        cycle detection   repeats after 32,768 iterations
L9 skip zero, unbounded       UNKNOWN      step budget
L10 odd perfect number        UNKNOWN      step budget       (an open problem in mathematics)
```

Diagrams used in the report and slides are in `docs/diagrams/`.
