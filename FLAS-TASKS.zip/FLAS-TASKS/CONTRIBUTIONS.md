# Contributions

## Tasks 2 and 3 (individual work)
Siva Balan S (RA2411026050230) – all of `automata/`, `task2/`, `task3/` and their tests.

## Task 4 (team work): LoopGuard – infinite-loop detection

| Member | Role | Contribution |
|---|---|---|
| Siva Balan S (RA2411026050230) | Modelling and analysis | problem formulation, HALT_TM / LOOP_TM, Turing machines M_A and M_B, diagonal undecidability proof, recognizability analysis, restricted decidable cases |
| Shabari Raj Kumar S (RA2411026050227) | Validation | `task4/loopguard.py` (fixed bound, linear ranking, cycle detection, step budget), ten-loop benchmark with hand-checked answers, `tests/test_task4.py` |
| Shailesh M (RA2411026050223) | Documentation | diagrams in `docs/diagrams/`, README, consolidated report and presentation |

All three members reviewed the benchmark results and the final report together.
