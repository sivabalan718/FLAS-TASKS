"""Task 4 tests: LoopGuard must never give a wrong proved verdict."""
import unittest

from task4 import loopguard as lg


class Verdicts(unittest.TestCase):
    def test_benchmark(self):
        expected = [lg.TERMINATES, lg.TERMINATES, lg.LOOPS, lg.LOOPS, lg.LOOPS,
                    lg.TERMINATES, lg.LOOPS, lg.LOOPS, lg.UNKNOWN, lg.UNKNOWN]
        for p, exp in zip(lg.BENCHMARK, expected):
            self.assertEqual(lg.analyse(p)[0], exp, p.name)


class Soundness(unittest.TestCase):
    def test_linear_check_matches_execution(self):
        """1,078 small loops: the static linear verdict agrees with actually running the loop."""
        n = 0
        for x0 in range(-5, 6):
            for c in range(-3, 4):
                for d in range(-3, 4):
                    for op in (">", "<"):
                        guard = (lambda s, c=c: s["x"] > c) if op == ">" else (lambda s, c=c: s["x"] < c)
                        p = lg.LoopProgram("t", "", {"x": x0}, guard, lambda s, d=d: {"x": s["x"] + d},
                                           linear=("x", op, c, d), budget=60)
                        static = lg.linear_check(p)[0]
                        run = lg.cycle_check(p)[0]
                        self.assertEqual(static, lg.LOOPS if run == lg.UNKNOWN else run, (x0, op, c, d))
                        n += 1
        self.assertEqual(n, 1078)

    def test_finite_domain_always_decided(self):
        """Every loop  while x != t: x = (x + d) mod 256  gets a proved verdict (never UNKNOWN)."""
        for d in range(256):
            for t in (0, 1, 100, 255):
                p = lg.LoopProgram("t", "", {"x": 5}, lambda s, t=t: s["x"] != t,
                                   lambda s, d=d: {"x": (s["x"] + d) % 256}, budget=300)
                self.assertNotEqual(lg.cycle_check(p)[0], lg.UNKNOWN, (d, t))

    def test_loops_verdict_really_repeats(self):
        """For each LOOPS-by-cycle verdict, running far past the cycle still never exits."""
        for p in lg.BENCHMARK:
            if p.cond and lg.analyse(p)[1] == "cycle detection" and lg.analyse(p)[0] == lg.LOOPS:
                s = dict(p.init)
                for _ in range(200_000):
                    self.assertTrue(p.cond(s), p.name)
                    s = p.body(s)


if __name__ == "__main__":
    unittest.main()
